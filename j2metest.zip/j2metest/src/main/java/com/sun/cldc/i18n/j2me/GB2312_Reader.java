/* 
    Copyright 2010 Blue Whale Systems Ltd
*/

package com.sun.cldc.i18n.j2me;

class GB2312_Reader extends Gen_Reader
{
    public GB2312_Reader() throws ClassNotFoundException
    {
        super("GB2312");
    }
}