/* 
    Copyright 2010 Blue Whale Systems Ltd
*/

package com.sun.cldc.i18n.j2me;

class KO18_R_Reader extends Gen_Reader
{
    public KO18_R_Reader() throws ClassNotFoundException
    {
        super("koi18_r");
    }
}