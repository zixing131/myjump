/* 
    Copyright 2010 Blue Whale Systems Ltd
*/

package com.sun.cldc.i18n.j2me;

class US_ASCII_Reader extends Gen_Reader
{
    public US_ASCII_Reader() throws ClassNotFoundException
    {
        super("us_ascii");
    }
}