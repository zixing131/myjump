/* 
    Copyright 2010 Blue Whale Systems Ltd
*/

package com.sun.cldc.i18n.j2me;

class WINDOWS_1252_Reader extends Gen_Reader
{
    public WINDOWS_1252_Reader() throws ClassNotFoundException
    {
        super("windows_1252");
    }
}