/* 
    Copyright 2010 Blue Whale Systems Ltd
*/

package com.sun.cldc.i18n.j2me;

public class GBK_Reader extends Gen_Reader
{
    public GBK_Reader() throws ClassNotFoundException
    {
        super("gbk");
    }
}