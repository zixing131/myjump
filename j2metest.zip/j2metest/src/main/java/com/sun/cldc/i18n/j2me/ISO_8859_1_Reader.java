/* 
    Copyright 2010 Blue Whale Systems Ltd
*/

package com.sun.cldc.i18n.j2me;

class ISO_8859_1_Reader extends Gen_Reader
{
    public ISO_8859_1_Reader() throws ClassNotFoundException
    {
        super("iso_8859_1");
    }
}